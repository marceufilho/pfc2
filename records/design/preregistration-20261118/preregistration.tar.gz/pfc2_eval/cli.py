"""`uv run --locked python -m pfc2_eval SUBCOMMAND`, from the repository root.

Every command that writes takes a new `--output` and supports `--dry-run`. Exit codes: 0 success, 1 failure,
2 usage error.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from pfc2.core.diagnostics import FrontendError
from pfc2.core.environment import ToolchainError
from pfc2.core.target import read_target
from pfc2_eval import adapter, build, campaign, generate, heldout, interpret, selfcheck

DEFAULT_CLANG = "clang-19"
CLANG_ENV = "PFC2_CLANG"
PLANNED = {
    "differential": "E1",
    "breakit": "E2",
    "inject": "E3",
    "mutate": "E4",
    "robustness": "E5",
    "crosscheck": "E6",
    "oracle": "E7",
    "traps": "E8",
    "replay": "E9",
    "proposers": "E10",
    "runtime": "E11",
    "surfaces": "E12",
    "corpus": "S1-S5",
}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pfc2_eval", description="Evaluation harness for PFC2.")
    commands = parser.add_subparsers(dest="command", required=True)

    check = commands.add_parser(
        "selfcheck",
        help="harness validation: the interpreter against the source compiled as plain C",
        epilog="example: python -m pfc2_eval selfcheck --output bench/eval/selfcheck-new --programs 200 --cases 50",
    )
    check.add_argument("--output", required=True, type=Path)
    check.add_argument("--seed", type=int, default=0)
    check.add_argument("--programs", type=int, default=200)
    check.add_argument("--cases", type=int, default=50)
    check.add_argument("--clang")
    check.add_argument("--dry-run", action="store_true")

    make = commands.add_parser(
        "generate", help="print the program of a seed", epilog="example: python -m pfc2_eval generate --seed 7"
    )
    make.add_argument("--seed", type=int, required=True)

    execute = commands.add_parser(
        "interpret",
        help="run one function in the reference interpreter",
        epilog='example: python -m pfc2_eval interpret FILE --function f --input \'{"scalars": {"n": 2}}\'',
    )
    execute.add_argument("file", type=Path)
    execute.add_argument("--function")
    execute.add_argument("--input", default="{}", help="JSON with scalars, arrays and globals by name")
    execute.add_argument("--clang")

    sealed = commands.add_parser("heldout", help="seal or verify a held-out directory")
    actions = sealed.add_subparsers(dest="action", required=True)
    sealing = actions.add_parser("seal", epilog='example: python -m pfc2_eval heldout seal DIR --rule "..."')
    sealing.add_argument("directory", type=Path)
    sealing.add_argument("--rule", required=True, help="the selection rule the set was drawn by")
    actions.add_parser("verify").add_argument("directory", type=Path)

    commands.add_parser("candidate", help="show which frozen candidate this tree is, as JSON")
    for name, step in PLANNED.items():
        commands.add_parser(name, help=f"not implemented yet (plan step {step})")
    return parser


def _interpret(options: argparse.Namespace, compiler: str) -> int:
    data = json.loads(options.input)
    if not isinstance(data, dict) or set(data) - {"scalars", "arrays", "globals"}:
        raise ValueError("--input is a JSON object with scalars, arrays and globals")
    inputs = interpret.Inputs(data.get("scalars", {}), data.get("arrays", {}), data.get("globals", {}))
    unit = adapter.load(options.file)
    observed = interpret.run(adapter.released(unit), inputs, target=read_target(compiler), function=options.function)
    if isinstance(observed, interpret.Observation):
        record = {
            "result": observed.result,
            "arrays": {name: list(values) for name, values in observed.arrays.items()},
            "globals": observed.globals,
            "output": observed.output,
            "annotation_violations": list(observed.annotation_violations),
        }
        print(json.dumps(record, indent=2, sort_keys=True))
        return 0
    print(json.dumps({"rejected": observed.kind, "message": observed.message}, indent=2, sort_keys=True))
    return 1


def main(arguments: list[str] | None = None) -> int:
    options = _parser().parse_args(arguments)
    compiler = getattr(options, "clang", None) or os.environ.get(CLANG_ENV, DEFAULT_CLANG)
    try:
        if options.command in PLANNED:
            print(
                f"pfc2_eval: {options.command} is plan step {PLANNED[options.command]} and is not implemented",
                file=sys.stderr,
            )
            return 1
        if options.command == "selfcheck":
            passed = selfcheck.run(
                output=options.output,
                compiler=compiler,
                seed=options.seed,
                programs=options.programs,
                cases=options.cases,
                dry_run=options.dry_run,
            )
            return 0 if passed else 1
        if options.command == "generate":
            print(generate.program(options.seed).text, end="")
            return 0
        if options.command == "interpret":
            return _interpret(options, compiler)
        if options.command == "candidate":
            frozen = campaign.candidate()
            record = {
                "candidate": frozen.name,
                "protected_sha256": frozen.protected_sha256,
                "intact": frozen.intact,
                "changed": list(frozen.protected.mismatched),
                "unlisted": list(frozen.unlisted),
            }
            print(json.dumps(record, indent=2, sort_keys=True))
            return 0 if frozen.intact else 1
        if options.action == "seal":
            count = heldout.seal(options.directory, rule=options.rule, candidate=campaign.candidate().name)
            print(f"sealed {count} files in {options.directory}")
            return 0
        state = heldout.verify(options.directory)
        print("intact" if state.intact else "; ".join(state.problems))
        return 0 if state.intact else 1
    except FileExistsError as error:
        print(f"pfc2_eval: {error}", file=sys.stderr)
        return 1
    except (FrontendError, ToolchainError, build.BuildError, OSError, ValueError) as error:
        print(f"pfc2_eval: {error}", file=sys.stderr)
        return 1
