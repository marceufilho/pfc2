# PFC2 to conference standard: fix the engine, evaluate it like PFC, and study tests versus proofs

Approved by the author on 2026-11-18. Status: **Phases 0 and 1 done** on 2026-11-18. Phase 0: engine review and
fixes (`docs/decisions/0063-engine-audit.md`). Phase 1: language growth (`0064-language-v1.md`), its independent
review (`0065-language-review.md`), and the frozen candidate `pfc2-v1` (`validation/freeze/`), which the author
has still to commit and tag. Phases 2 to 6 have not started.
Nothing in this plan is a result. Supporting material: [REFERENCES.md](REFERENCES.md), [CORPORA.md](CORPORA.md).

## Context

You want PFC2 to become the main contribution of the paper and, if it holds up, of the TCC, with "from PFC to
PFC2" as the story and rigour fit for a top venue. Your decisions: a two-part paper (engine soundness + a corpus
study of well-tested modules); grow the language by a minimum set of features first; no fixed deadline; I draft
ports and contracts under a recorded protocol and you review a pre-registered sample. Modules first, about ten
whole programs later.

Four read-only investigations fed this plan. Their findings:

- **The engine is currently weaker than PFC.** Confirmed by running programs: a certified out-of-bounds read
  (generated names shadow a global), a false termination claim (a `decreases` silently dropped on a one-line loop),
  `assert` with a call that executes only in the certified build, `a[f()] += 1` calling `f` twice, macro
  substitution inside number literals, and a hole in the impossible-contract check. The changed admission rule was
  checked construct by construct and held.
- **The PFC harness is half reusable.** Evidence sealing, statistics, pre-registration, held-out sealing and table
  generation do not depend on the compiler. The experiments do, and several need redesign: PFC2 has no plain mode
  and no restrict/assume facts, it always infers counter bounds (which would solve the old held-out tasks before
  any proposer runs), and none of the 139 old corpus programs loads unchanged.
- **The corpus idea is valid and new, at module scale.** No study found measures how many existing tests become
  redundant once contracts are proved. Comparable benchmarks use 150–200 units of 10–80 lines (Verina 189,
  CLEVER 161), not programs of thousands of lines.
- The literature search is still running; its result goes into the references deliverable below.

Everything happens in `/home/marceu/pfc2`. The thesis repository is read, never written.

## Phase 0 — Make the engine sound (blocks everything else)

Each defect gets a failing test first, then the fix, then a general guard so the class cannot recur.

| Defect | Fix | Guard for the class |
| --- | --- | --- |
| Generated names shadow globals | emitter reserves global names; source may not use the `pfc_` prefix | test: no declaration in emitted C reuses any source name |
| `decreases` dropped, termination still reported | attach measures by clause identity, not by column | every clause must be consumed, or the file is refused |
| `assert` containing a call runs the call | refuse calls inside `assert`; a law keeps them (laws are never emitted) | plain-C build vs certified build agree on observable state |
| `a[f()] += 1` evaluates `f` twice | evaluate the index once into a temporary | compound assignment tests with calls in the index |
| Macros replaced inside literals; no rescan | real tokenizer; rescan; refuse redefining keywords | generated macro inputs compared with `cpp` |
| Contradictory external contract that reads arrays passes | treat memory the function cannot write as an input of the totality query; refuse `unknown` | pairs of possible/impossible contracts with arrays |
| External could re-enter the unit | cannot be checked: stated in the proof file and in Limits as an assumption | — |
| Inference never tries "no candidate" | fix the loop | test with a correct program that only passes without candidates |

Also: correct the wrong "left to right" comment, refuse a parameter named `result`, re-check `where` types after
calls that write a mentioned global, fix the matrix example (calls inside `assert`).

## Phase 1 — Minimum language growth, then freeze

`%` (truncating, as C), `break`/`continue`/early exit, local fixed-size arrays, `char`/`int` element types with
string literals as arrays. One ADR per feature with its semantics in the VC generator and emitter, hand-derived
obligation tests, a refused neighbour per feature, examples, docs, LSP and playground kept in step.

Then **freeze `pfc2-v1`**: a hash inventory of the package and tests (the PFC mechanism), and a tag you create.
Every later result names that identity. A fix after the freeze is a recorded amendment and a new candidate.

## Phase 2 — Evaluation harness `pfc2_eval/` (outside the package; the core never imports it)

- Reused as they are from `pfc_eval`: `evidence.py`, `stats.py`, `campaign.py`, `heldout.py`, `guards.py`,
  `tables.py`, the pre-registration and table/figure tools.
- New **reference interpreter** for PFC2's IR, sharing only the front end with the compiler: globals, externals
  backed by concrete stubs that are also linked into the binaries, an output trace, typed rejections. It must not
  import `vc`, `wp`, `smt`, `emit` or `authorization` (enforced by a test).
- A **random program generator** for the subset (in the spirit of Csmith): well-formed programs with globals,
  calls, loops with known invariants, arrays, the new features. PFC never needed one; PFC2's wider language does.
- An adapter exposing load / check with inference on or off / emit checked or verified / admit.

## Phase 3 — Part 1 of the paper: is the engine sound? (confirmatory, pre-registered)

| Experiment | What changes from PFC | Criterion (as in PFC unless noted) |
| --- | --- | --- |
| Differential | four-way: interpreter, checked C, certified C, and the source compiled as plain C; all binaries under ASan/UBSan; 1,000 inputs per program plus generated programs | 0 divergences, exact binomial bound reported |
| Break-it | each `requires` conjunct, each invariant conjunct, each `ensures` a caller relies on | sensitivity and specificity 100% |
| False-invariant injection | through `check` with inference off | 100% of independently false candidates refused |
| Mutation of PFC2 | core and surface passes; whole population, not a sample | score ≥ 0.90, survivors classified |
| Metamorphic robustness | renaming, reordering, **reformatting**, macro vs literal | identical verdicts and decisions |
| Second solver | cvc5 on every query | 0 disagreements |
| Independent oracle | Frama-C/WP on the units expressible in ACSL | 0 unclassified disagreements |
| Expected traps | overflow and precondition violations must trap | 100% |
| Proof-file replay / audit | every certificate recomputed offline | 0 differences |
| Proposers | no inference / built-in inference / Houdini / Daikon-style / LLM with and without feedback | pre-registered contrasts on a **new** sealed set |
| Runtime | checked vs certified vs plain source; trap ablation; controlled machine or labelled exploratory | descriptive |
| Editor and browser | LSP and playground results equal the command line on every program | identical |

Corpora: derived copies of the PFC corpora (regression strata, declared not unseen); PFC2-native generated
programs; and a new held-out set from SV-COMP directories PFC never used, selected by rule and sealed after the
freeze.

## Phase 4 — Part 2: tests versus proofs on well-tested modules

- **Sources**, each pinned to a commit: Exercism C track with its canonical test data (MIT, per-exercise tests);
  Juliet integer and index cases (good/bad pairs give ground-truth bugs); small kernels from permissive libraries
  with their own tests; Verina/MBPP tasks re-expressed in C (specs and tests written by others).
- **Selection rule, registered before any outcome**: enumerate all units in order; include every unit that ports
  under a fixed, published list of mechanical rules; exclude only by rule, with the reason recorded. Target 150–200.
- **Protocol**: I port and write the contract by the rules; contracts are frozen before mutants or subsumption
  queries run; you review a pre-registered random sample (rate reported, every disagreement recorded); specs that
  exist independently form their own stratum.
- **Measurements**
  1. Port rate and exclusion reasons; proof rate at a fixed budget; annotation lines per code line; time per unit.
  2. **Test subsumption**: each upstream test assertion restated as a fixed-input law and asked of the contract
     alone. Proved means the test is redundant given the contract.
  3. **Mutation 2×2** per unit: tests kill / proof rejects, on dominator mutants, counting only rejections with a
     counterexample.
  4. **Defects**: counted only when reproduced on the upstream code with a concrete input; defects of our port and
     of our spec reported separately.
  5. Juliet: bad variants refused, good variants certified.
- **Then about ten whole small programs** (a game, the REST API, a calendar, a ring buffer with a state machine)
  as case studies with effort data: qualitative, no statistics.

## Phase 5 — Pre-registration (written before Phase 3 and 4 outcomes exist)

Hypotheses, thresholds, selection rules, analysis and stopping rules in `paper/DESIGN.md`; a dated bundle with the
frozen inventory; an amendments log from day one. Results obtained before registration (today's tests, the audit)
are labelled exploratory.

## Phase 6 — Paper, TCC and references

- Structure: the problem; PFC in brief with its published evaluation as the starting point; what a usable language
  needed and what each addition costs in trust (**from PFC to PFC2**); Part 1; Part 2; the defects the audit found
  in PFC2 itself and how the evaluation would have caught each (reported, not hidden); threats; related work.
- `docs/references.md`: every source verified against a publisher page, DBLP, arXiv or Crossref, grouped by the
  claim or experiment it supports; unverified items marked.
- A scorecard of every registered criterion, met or not, generated from sealed evidence.

## Order and stopping points

0 → 1 → freeze → 2 → 5 → 3 → 4 → 6. After Phase 0 PFC2 is safe to use; after Phase 3 there is a complete
engine paper; Phase 4 adds the novel part. This is many sessions of work.

## Verification

- Phase 0: each defect's program is refused or correct; `make check` green; the audit's candidate programs become
  permanent tests.
- Phase 1: per-feature tests; agreement test with PFC unchanged except listed differences.
- Phase 2: interpreter agrees with plain-C binaries on generated programs; import-independence test.
- Phases 3–4: every campaign sealed (write-once records, schema, manifest); tables generated only from sealed
  directories with `--check`; scorecard reproduces from scratch.

## Risks stated plainly

- More defects will surface once generated programs and mutation run; that is the purpose, and each one is an
  amendment, not a failure of the plan.
- The feature unlock counts are estimates; the real port rate is itself a result.
- I draft the specs having seen the tests. The independent-spec stratum and your sampled review limit this; they do
  not remove it.
- Runtime results stay exploratory unless a machine with a fixed governor and a counter is used.
