# Amendments to the pre-registered design

Every change to [DESIGN.md](DESIGN.md) after 2026-11-18 is an entry here: date, what changes, why, and whether an
outcome it concerns had already been seen. An entry never rewrites an earlier one. Candidates are listed with
the experiments run on each.

## Candidates

| Candidate | Protected inventory SHA-256 | Frozen | Experiments run on it |
| --- | --- | --- | --- |
| `pfc2-v1` | `b65f0bc9810bc10ac0301e107f2d38337f3ba37b2f9f273664ccc1e3a58ea719` | 2026-11-18 | harness self-check (no engine decision) |

## Entries

None yet.
